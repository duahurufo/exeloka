# 🌐 ROOT DOMAIN DEPLOYMENT GUIDE

## 🎯 Your Website: https://www.forrestofus.com/

This bundle deploys your Exeloka app directly to the root domain instead of a subfolder.

## 📦 What's in this ZIP
- ✅ **Frontend Files** - Go directly to `public_html/` root
- ✅ **Backend Source** - For Node.js app setup
- ✅ **Database SQL** - For phpMyAdmin import

---

## 🚀 STEP 1: Upload Frontend to Root Domain

### 1.1 Upload to cPanel
1. **Upload this ZIP** to cPanel File Manager
2. **Extract in `public_html/`** (NOT in a subfolder!)
3. **Result:** Files go directly to `public_html/` root

### 1.2 Final Structure
```
public_html/
├── index.html              # ✅ Your homepage
├── dashboard/              # ✅ Dashboard pages  
│   ├── index.html
│   ├── projects/
│   ├── recommendations/
│   ├── analytics/
│   ├── knowledge/
│   ├── learning/
│   ├── documents/
│   └── settings/
├── login/index.html        # ✅ Login page
├── register/index.html     # ✅ Registration page
├── _next/                  # ✅ Next.js assets
├── backend/               # Backend source (don't upload to web)
└── database/              # Database files (don't upload to web)
```

**⚠️ Important:** Only the frontend files (index.html, dashboard/, login/, register/, _next/) should be in public_html. The backend/ and database/ folders are for separate setup.

---

## 🗄️ STEP 2: Database Setup

### 2.1 Create Database
1. **cPanel → MySQL Databases**
2. **Database:** `forresto_exeloka`
3. **User:** `forresto_exeloka_user` 
4. **Password:** `Kmzways1a7!!!@@@`
5. **Grant all privileges**

### 2.2 Import Data
1. **Open phpMyAdmin**
2. **Select** `forresto_exeloka` database
3. **Import** `database/exeloka_database.sql`

---

## ⚙️ STEP 3: Backend Setup (Node.js App)

### 3.1 cPanel Node.js Setup Form
Fill out your Node.js form with these values:

- **Node.js version:** `18.x` or `20.x` (Latest LTS)
- **Application mode:** `Production`
- **Application root:** `/home/[username]/exeloka_backend`
- **Application URL:** `https://www.forrestofus.com/api`
- **Application startup file:** `server.js`

### 3.2 Upload Backend
1. **Upload `backend/` folder contents** to the Node.js Application Root
2. **Click "NPM Install"** in cPanel
3. **Add Environment Variables:**
```
NODE_ENV=production
DB_HOST=localhost
DB_USER=forresto_exeloka_user
DB_PASSWORD=Kmzways1a7!!!@@@
DB_NAME=forresto_exeloka
OPENROUTER_API_KEY=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
JWT_SECRET=exeloka-super-secure-jwt-key-forresto-2024-prod
FRONTEND_URL=https://www.forrestofus.com
PORT=3000
```
4. **Start the app**

---

## ✅ Final Result

### Your Live URLs:
- **🌐 Website:** https://www.forrestofus.com/
- **📊 Dashboard:** https://www.forrestofus.com/dashboard/
- **🔑 Login:** https://www.forrestofus.com/login/
- **👤 Register:** https://www.forrestofus.com/register/
- **🔧 API:** https://www.forrestofus.com/api/

### Complete Architecture:
```
https://www.forrestofus.com/        # 🌐 Frontend (Root Domain)
https://www.forrestofus.com/api/    # ⚙️ Backend API  
forresto_exeloka                    # 🗄️ MySQL Database
```

---

## 🎉 Root Domain Deployment Complete!

**Your Exeloka Cultural Wisdom app is now live at the root domain!**

No more `/exeloka` subfolder - everything is directly at **www.forrestofus.com**!