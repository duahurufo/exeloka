import fs from 'fs/promises';
import path from 'path';
import axios from 'axios';
import FormData from 'form-data';
import { logger } from '../utils/logger';
import { createError } from '../middleware/errorHandler';
import Tesseract from 'tesseract.js';

interface OCRResult {
  text: string;
  confidence: number;
  metadata: Record<string, any>;
}

interface OCROptions {
  language?: string;
  method?: 'tesseract' | 'cloud'; // Future: Add cloud OCR providers
  enhanceImage?: boolean;
}

class OCRService {
  private defaultOptions: OCROptions = {
    language: 'eng+ind', // English + Indonesian
    method: 'tesseract',
    enhanceImage: true
  };

  async extractTextFromFile(filePath: string, options: OCROptions = {}): Promise<OCRResult> {
    const opts = { ...this.defaultOptions, ...options };
    
    try {
      logger.info('Starting OCR extraction', { filePath, options: opts });

      const fileExtension = path.extname(filePath).toLowerCase();
      
      // Check if file is an image that can be processed by OCR
      const imageExtensions = ['.jpg', '.jpeg', '.png', '.tiff', '.bmp', '.webp'];
      if (!imageExtensions.includes(fileExtension)) {
        throw createError(`OCR not supported for file type: ${fileExtension}. Supported: ${imageExtensions.join(', ')}`, 400);
      }

      // Check if file exists
      await fs.access(filePath);

      if (opts.method === 'tesseract') {
        return await this.extractWithTesseract(filePath, opts);
      } else {
        throw createError(`OCR method '${opts.method}' not implemented yet`, 400);
      }

    } catch (error: any) {
      logger.error('OCR extraction failed', { filePath, error: error.message });
      throw error;
    }
  }

  private async extractWithTesseract(filePath: string, options: OCROptions): Promise<OCRResult> {
    try {
      logger.info('Using Tesseract.js for OCR', { filePath });

      const { data } = await Tesseract.recognize(filePath, options.language || 'eng+ind', {
        logger: (m) => {
          if (m.status === 'recognizing text') {
            logger.debug(`OCR Progress: ${Math.round(m.progress * 100)}%`);
          }
        }
      });

      const result: OCRResult = {
        text: data.text.trim(),
        confidence: data.confidence,
        metadata: {
          method: 'tesseract',
          language: options.language,
          processing_time: Date.now(),
          word_count: data.words?.length || 0,
          line_count: data.lines?.length || 0,
          paragraph_count: data.paragraphs?.length || 0
        }
      };

      logger.info('Tesseract OCR completed', {
        confidence: result.confidence,
        textLength: result.text.length,
        wordCount: result.metadata.word_count
      });

      return result;
    } catch (error: any) {
      logger.error('Tesseract OCR failed', { error: error.message });
      throw createError(`Tesseract OCR failed: ${error.message}`, 500);
    }
  }

  async extractTextFromBuffer(buffer: Buffer, filename: string, options: OCROptions = {}): Promise<OCRResult> {
    const opts = { ...this.defaultOptions, ...options };
    
    try {
      // Create a temporary file
      const tempDir = process.env.TEMP_DIR || './temp';
      await fs.mkdir(tempDir, { recursive: true });
      
      const tempPath = path.join(tempDir, `ocr_${Date.now()}_${filename}`);
      await fs.writeFile(tempPath, buffer);

      try {
        const result = await this.extractTextFromFile(tempPath, opts);
        return result;
      } finally {
        // Clean up temporary file
        try {
          await fs.unlink(tempPath);
        } catch (cleanupError) {
          logger.warn('Failed to cleanup temp OCR file', { tempPath, error: cleanupError });
        }
      }
    } catch (error: any) {
      logger.error('OCR from buffer failed', { filename, error: error.message });
      throw error;
    }
  }

  // Future: Implement cloud OCR providers
  private async extractWithCloudProvider(filePath: string, provider: string): Promise<OCRResult> {
    // TODO: Implement cloud OCR providers like:
    // - Google Cloud Vision API
    // - Azure Computer Vision
    // - AWS Textract
    // - OpenAI Vision API
    
    throw createError(`Cloud OCR provider '${provider}' not implemented yet`, 501);
  }

  async isOCRCapable(filePath: string): Promise<boolean> {
    const fileExtension = path.extname(filePath).toLowerCase();
    const imageExtensions = ['.jpg', '.jpeg', '.png', '.tiff', '.bmp', '.webp'];
    return imageExtensions.includes(fileExtension);
  }

  async preprocessImage(filePath: string): Promise<string> {
    // TODO: Implement image preprocessing for better OCR results
    // - Noise reduction
    // - Contrast enhancement
    // - Deskewing
    // - Binarization
    
    logger.info('Image preprocessing not implemented yet', { filePath });
    return filePath; // Return original path for now
  }

  // Validate OCR result quality
  validateOCRResult(result: OCRResult): { isValid: boolean; issues: string[] } {
    const issues: string[] = [];
    
    if (result.confidence < 30) {
      issues.push('Very low OCR confidence (< 30%)');
    }
    
    if (result.text.length < 10) {
      issues.push('Extracted text too short (< 10 characters)');
    }
    
    if (result.text.trim() === '') {
      issues.push('No text extracted');
    }
    
    // Check for garbled text patterns
    const garbageRatio = (result.text.match(/[^\w\s.,!?;:()-]/g) || []).length / result.text.length;
    if (garbageRatio > 0.3) {
      issues.push('High ratio of unrecognizable characters');
    }

    return {
      isValid: issues.length === 0,
      issues
    };
  }
}

export const ocrService = new OCRService();